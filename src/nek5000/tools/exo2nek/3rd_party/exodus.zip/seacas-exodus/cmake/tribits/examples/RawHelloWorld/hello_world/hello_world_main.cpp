#include <iostream>
#include "hello_world_lib.hpp"
int main() {
  std::cout << HelloWorld::getHelloWorld() << "\n";
  return 0;
}
