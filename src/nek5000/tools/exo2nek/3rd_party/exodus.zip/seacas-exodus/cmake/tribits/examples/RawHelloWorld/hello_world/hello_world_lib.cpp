#include "hello_world_lib.hpp"
std::string HelloWorld::getHelloWorld()
{ return "Hello World!"; }
