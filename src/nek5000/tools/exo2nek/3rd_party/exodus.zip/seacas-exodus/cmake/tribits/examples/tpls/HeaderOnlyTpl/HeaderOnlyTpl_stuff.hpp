#ifndef HEADER_ONLY_TPL_STUFF_HPP
#define HEADER_ONLY_TPL_STUFF_HPP


namespace HeaderOnlyTpl {

/** \brief . */
template <typename T>
T  sqr(const T &v)
{
  return v*v;
}

} // namespace HeaderOnlyTpl


#endif // HEADER_ONLY_TPL_STUFF_HPP
